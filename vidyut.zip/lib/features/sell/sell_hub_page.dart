import 'package:flutter/material.dart';
import 'hub_shell.dart';

class SellHubPage extends StatelessWidget {
  const SellHubPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SellHubShell();
  }
}
