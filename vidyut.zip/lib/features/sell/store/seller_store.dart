import 'package:flutter/foundation.dart';
import '../models.dart';
import 'dart:math';

class SellerStore extends ChangeNotifier {
  List<Product> _products = [];
  List<CustomFieldDef> _profileFields = [];
  List<Lead> _leads = [];
  String _bannerUrl = '';
  List<String> _profileMaterials = [];
  List<AdCampaign> _ads = [];

  // Getters
  List<Product> get products => List.unmodifiable(_products);
  List<CustomFieldDef> get profileFields => List.unmodifiable(_profileFields);
  List<Lead> get leads => List.unmodifiable(_leads);
  String get bannerUrl => _bannerUrl;
  List<String> get profileMaterials => List.unmodifiable(_profileMaterials);
  List<AdCampaign> get ads => List.unmodifiable(_ads);

  SellerStore() {
    _seedDemoData();
  }

  void seedDemoProductsIfEmpty() {
    if (_products.isNotEmpty) return;
    final r = Random(42);
    for (int i = 0; i < 14; i++) {
      _products.add(Product(
        id: 'P${i + 1}',
        title: 'Cable ${i + 1}',
        brand: i.isEven ? 'Finolex' : 'Polycab',
        category: kCategories[i % kCategories.length],
        subtitle: 'Spec ${i + 1}',
        price: 300 + i * 120.0,
        moq: 10,
        gstRate: 18,
        materials: [if (i.isEven) 'Copper' else 'Aluminium', 'PVC'],
        status: i % 5 == 0 ? ProductStatus.draft : ProductStatus.active,
        rating: (r.nextDouble() * 2) + 3, // 3..5
      ));
    }
    notifyListeners();
  }

  // Banner management
  void setBannerUrl(String url) {
    _bannerUrl = url;
    notifyListeners();
    // TODO(firebase): sync to backend
  }

  void setProfileMaterials(List<String> materials) {
    _profileMaterials = List.of(materials);
    notifyListeners();
    // TODO(firebase): sync to backend
  }

  // Ads management (max 3 campaigns)
  void upsertAd(AdCampaign ad) {
    final i = _ads.indexWhere((a) => a.id == ad.id);
    if (i == -1) {
      if (_ads.length >= 3) return; // cap at 3
      _ads.add(ad);
    } else {
      _ads[i] = ad;
    }
    notifyListeners();
  }

  void deleteAd(String id) {
    _ads.removeWhere((a) => a.id == id);
    notifyListeners();
  }

  void _seedDemoData() {
    // Seed demo products
    _products = [
      Product(
        id: '1',
        title: 'Copper Cable 1.5sqmm',
        brand: 'Philips',
        subtitle: 'PVC | 1.5 sqmm | 1100V',
        description:
            'High-quality copper cable suitable for electrical wiring in residential and commercial buildings.',
        images: ['https://picsum.photos/seed/cable1/800/600'],
        price: 499.0,
        moq: 100,
        gstRate: 18.0,
        materials: ['Copper', 'PVC'],
        customValues: {'color': 'Red', 'length': '100m'},
      ),
      Product(
        id: '2',
        title: 'Aluminum Wire 2.5sqmm',
        brand: 'Havells',
        subtitle: 'XLPE | 2.5 sqmm | 1100V',
        description:
            'Durable aluminum wire with XLPE insulation for industrial applications.',
        images: ['https://picsum.photos/seed/wire1/800/600'],
        price: 299.0,
        moq: 50,
        gstRate: 18.0,
        materials: ['Aluminum', 'XLPE'],
        customValues: {'color': 'Black', 'length': '50m'},
      ),
      Product(
        id: '3',
        title: 'MCB 32A Single Pole',
        brand: 'Schneider',
        subtitle: '32A | Single Pole | DIN Rail',
        description:
            'Miniature Circuit Breaker for electrical protection in distribution boards.',
        images: ['https://picsum.photos/seed/mcb1/800/600'],
        price: 899.0,
        moq: 10,
        gstRate: 18.0,
        materials: ['Plastic', 'Metal'],
        customValues: {'rating': '32A', 'type': 'Single Pole'},
      ),
    ];

    // Seed demo profile fields
    _profileFields = const [
      CustomFieldDef(
        id: 'business_type',
        label: 'Business Type',
        type: FieldType.dropdown,
        options: ['Manufacturer', 'Distributor', 'Retailer', 'Wholesaler'],
      ),
      CustomFieldDef(
        id: 'certification',
        label: 'ISO Certification',
        type: FieldType.boolean,
      ),
      CustomFieldDef(
        id: 'established_year',
        label: 'Established Year',
        type: FieldType.number,
      ),
    ];

    // Seed demo leads
    _leads = [
      Lead(
        id: '1',
        title: 'Bulk Cable Order for Construction Project',
        industry: 'Construction',
        materials: ['Copper', 'PVC'],
        city: 'Mumbai',
        state: 'Maharashtra',
        qty: 5000,
        turnoverCr: 85,
        needBy: DateTime.now().add(const Duration(days: 30)),
        status: 'New',
        about: 'Large wiring scope for construction project.',
      ),
      Lead(
        id: '2',
        title: 'Industrial Wiring for Factory Setup',
        industry: 'EPC',
        materials: ['Aluminium', 'XLPE'],
        city: 'Pune',
        state: 'Maharashtra',
        qty: 2000,
        turnoverCr: 120,
        needBy: DateTime.now().add(const Duration(days: 45)),
        status: 'In Progress',
        about: 'Factory electrical infrastructure.',
      ),
      Lead(
        id: '3',
        title: 'Electrical Components for Office Complex',
        industry: 'MEP',
        materials: ['Copper', 'PVC'],
        city: 'Bangalore',
        state: 'Karnataka',
        qty: 500,
        turnoverCr: 60,
        needBy: DateTime.now().add(const Duration(days: 15)),
        status: 'Quoted',
        about: 'Office complex electrical upgrade.',
      ),
    ];

    // Seed demo profile materials
    _profileMaterials = const ['Copper', 'PVC'];
    // Seed demo ads
    _ads = [
      AdCampaign(id: 'ad1', type: AdType.search, term: 'copper', slot: 2),
      AdCampaign(
          id: 'ad2', type: AdType.category, term: 'Cables & Wires', slot: 3),
    ];
  }

  // Product CRUD
  void addProduct(Product product) {
    _products.add(product);
    notifyListeners();
    // TODO(firebase): sync to Firestore
  }

  void updateProduct(Product product) {
    final index = _products.indexWhere((p) => p.id == product.id);
    if (index != -1) {
      _products[index] = product;
      notifyListeners();
      // TODO(firebase): sync to Firestore
    }
  }

  void deleteProduct(String productId) {
    _products.removeWhere((p) => p.id == productId);
    notifyListeners();
    // TODO(firebase): sync to Firestore
  }

  Product? getProduct(String productId) {
    try {
      return _products.firstWhere((p) => p.id == productId);
    } catch (e) {
      return null;
    }
  }

  // Profile Fields CRUD
  void addProfileField(CustomFieldDef field) {
    _profileFields.add(field);
    notifyListeners();
    // TODO(firebase): sync to Firestore
  }

  void updateProfileField(CustomFieldDef field) {
    final index = _profileFields.indexWhere((f) => f.id == field.id);
    if (index != -1) {
      _profileFields[index] = field;
      notifyListeners();
      // TODO(firebase): sync to Firestore
    }
  }

  void deleteProfileField(String fieldId) {
    _profileFields.removeWhere((f) => f.id == fieldId);
    notifyListeners();
    // TODO(firebase): sync to Firestore
  }

  // Lead management
  void updateLeadStatus(String leadId, String status) {
    final index = _leads.indexWhere((l) => l.id == leadId);
    if (index != -1) {
      final lead = _leads[index];
      _leads[index] = Lead(
        id: lead.id,
        title: lead.title,
        industry: lead.industry,
        materials: lead.materials,
        city: lead.city,
        state: lead.state,
        qty: lead.qty,
        turnoverCr: lead.turnoverCr,
        needBy: lead.needBy,
        status: status,
        about: lead.about,
      );
      notifyListeners();
      // TODO(firebase): sync to Firestore
    }
  }
}

enum AdType { search, category }

class AdCampaign {
  final String id;
  final AdType type;
  final String term; // keyword or category name
  final int slot; // desired 1..5
  const AdCampaign(
      {required this.id,
      required this.type,
      required this.term,
      required this.slot});
}
