import 'package:flutter/material.dart';
import 'product_card.dart';
import '../../sell/product_detail_page.dart';
import '../../sell/models.dart';

class ProductsGrid extends StatelessWidget {
  final double radiusKm;
  const ProductsGrid({super.key, required this.radiusKm});

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      sliver: SliverLayoutBuilder(
        builder: (context, constraints) {
          final availableWidth = constraints.crossAxisExtent;
          final crossAxisCount = _getCrossAxisCount(availableWidth);
          final spacing = _getSpacing(availableWidth);

          return SliverGrid(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: crossAxisCount,
              mainAxisSpacing: spacing,
              crossAxisSpacing: spacing,
              childAspectRatio: 0.75, // Slightly taller for better content fit
            ),
            delegate: SliverChildBuilderDelegate(
              (context, index) => ProductCard.demo(
                index: index,
                onTap: () {
                  final p = Product(
                    id: 'H${index + 1}',
                    title: 'Copper Cable ${index + 1}',
                    brand: 'Philips',
                    subtitle: 'Cables & Wires',
                    price: (499 + index * 20).toDouble(),
                    materials: const ['Copper', 'PVC'],
                    moq: 100,
                    gstRate: 18,
                    description:
                        'High-quality copper cable suitable for residential and commercial wiring.',
                  );
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ProductDetailPage(product: p),
                    ),
                  );
                },
              ),
              childCount: 12,
            ),
          );
        },
      ),
    );
  }

  int _getCrossAxisCount(double availableWidth) {
    if (availableWidth >= 1200) return 4; // Desktop
    if (availableWidth >= 900) return 3; // Large tablet
    if (availableWidth >= 600) return 2; // Tablet
    return 1; // Mobile
  }

  double _getSpacing(double availableWidth) {
    if (availableWidth >= 1200) return 16;
    if (availableWidth >= 900) return 12;
    if (availableWidth >= 600) return 10;
    return 8;
  }
}
