import 'dart:async';
import 'package:flutter/material.dart';
import '../../../app/breakpoints.dart';
import '../../../app/tokens.dart';

class HeroSlideshow extends StatefulWidget {
  const HeroSlideshow({super.key});

  @override
  State<HeroSlideshow> createState() => _HeroSlideshowState();
}

class _HeroSlideshowState extends State<HeroSlideshow> {
  final _controller = PageController();
  int _index = 0;
  Timer? _timer;

  final _slides = const [
    _SlideData(
      'India\'s Largest Electricity Info Platform',
      'B2B • D2C • C2C — Produced by Madhu Powertech',
    ),
    _SlideData(
      'Find the right components fast',
      'Search by brand, spec, and materials used',
    ),
    _SlideData(
      'Post RFQs & get quotes',
      'Verified sellers, transparent pricing',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      _index = (_index + 1) % _slides.length;
      _controller.animateToPage(
        _index,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    final isDesktop = w >= AppBreakpoints.desktop;

    final double height = isDesktop ? 420 : 320; // increased mobile height
    return Container(
      height: height,
      // Removed background color to eliminate the annoying green/gray background
      child: PageView.builder(
        controller: _controller,
        itemCount: _slides.length,
        itemBuilder: (_, i) {
          final s = _slides[i];
          return Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1200),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: isDesktop
                    ? Row(
                        children: [
                          Expanded(
                            child: _SlideText(
                              title: s.title,
                              subtitle: s.subtitle,
                            ),
                          ),
                          const SizedBox(width: 16),
                          // Placeholder image area (we'll replace with real banners later)
                          Expanded(
                            child: AspectRatio(
                              aspectRatio: 4 / 3,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppColors.thumbBg,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: AppColors.outlineSoft,
                                  ),
                                ),
                                child: const Icon(
                                  Icons.image,
                                  size: 48,
                                  color: Colors.black54,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Flexible(
                            child: _SlideText(
                              title: s.title,
                              subtitle: s.subtitle,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Flexible(
                            child: AspectRatio(
                              aspectRatio:
                                  2 / 1, // shorter aspect ratio for mobile
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppColors.thumbBg,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: AppColors.outlineSoft,
                                  ),
                                ),
                                child: const Icon(
                                  Icons.image,
                                  size: 32, // smaller icon for mobile
                                  color: Colors.black54,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _SlideText extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SlideText({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    final isDesktop = w >= AppBreakpoints.desktop;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Flexible(
          child: Text(
            title,
            textAlign: TextAlign.center,
            maxLines: isDesktop ? 2 : 3,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                  fontSize: isDesktop
                      ? null
                      : Theme.of(context).textTheme.headlineLarge!.fontSize! *
                          0.8,
                ),
          ),
        ),
        const SizedBox(height: 8),
        Flexible(
          child: Text(
            subtitle,
            textAlign: TextAlign.center,
            maxLines: isDesktop ? 2 : 3,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontSize: isDesktop
                      ? null
                      : Theme.of(context).textTheme.titleMedium!.fontSize! *
                          0.9,
                ),
          ),
        ),
      ],
    );
  }
}

class _SlideData {
  final String title;
  final String subtitle;
  const _SlideData(this.title, this.subtitle);
}
