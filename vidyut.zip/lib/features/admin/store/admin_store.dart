import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AdminStore extends ChangeNotifier {
  AdminStore() {
    _hydrate();
  }

  // Demo users data
  final List<AdminUser> _allUsers = List.generate(30, (i) => AdminUser(
        id: 'U${1000 + i}',
        name: i % 3 == 0 ? 'John Doe' : i % 3 == 1 ? 'Aarti' : 'Rahul',
        email: 'user${i}@example.com',
        role: i % 5 == 0 ? 'admin' : 'seller',
        status: i % 4 == 0 ? 'suspended' : i % 3 == 0 ? 'pending' : 'active',
        createdAt: DateTime.now().subtract(Duration(days: 30 - i)),
        isSeller: i % 2 == 0,
        plan: i % 6 == 0 ? 'pro' : i % 3 == 0 ? 'plus' : 'free',
        sellerProfile: i % 2 == 0
            ? const SellerProfile(
                legalName: 'Demo Co.',
                phone: '+91-9999999999',
                address: 'Somewhere, India',
                materials: ['Copper', 'PVC'],
              )
            : null,
      ));

  // Feature flags (demo, in-memory)
  final Map<String, bool> _featureFlags = {
    'new_search': true,
    'lead_scoring': false,
    'ads_v2': true,
    'kyc_strict': false,
  };

  // Audit logs (demo)
  final List<AuditLog> _auditLogs = [];
  int _auditRetentionDays = 30;

  // RBAC roles and permissions (demo, in-memory)
  final Map<String, Set<String>> _roleToPermissions = {
    'admin': {
      'users.read','users.write','sellers.read','sellers.write','kyc.review','products.read','products.write','uploads.review','ads.manage','leads.manage','orders.manage','messaging.moderate','cms.manage','billing.manage','search.tune','geo.manage','analytics.view','compliance.manage','system.ops','feature.flags','rbac.manage','audit.read','bulk.ops','notifications.send','export.data','dev.tools'
    },
    'seller': {'products.read','products.write','orders.manage','leads.manage','messaging.use'},
    'buyer': {'products.read','messaging.use','orders.manage'},
  };
  Map<String, Set<String>> get roleToPermissions => {
    for (final e in _roleToPermissions.entries) e.key: Set<String>.from(e.value)
  };

  Future<void> createRole(String role, {Iterable<String> permissions = const []}) async {
    if (_roleToPermissions.containsKey(role)) return;
    _roleToPermissions[role] = {...permissions};
    await addAudit('rbac', 'Created role "$role" with ${permissions.length} perms');
    notifyListeners();
    await _persistRBAC();
  }

  Future<void> deleteRole(String role) async {
    if (role == 'admin' || role == 'seller' || role == 'buyer') return; // protect core roles
    if (_roleToPermissions.remove(role) != null) {
      await addAudit('rbac', 'Deleted role "$role"');
      notifyListeners();
      await _persistRBAC();
    }
  }

  Future<void> grantPermissionToRole(String role, String permission) async {
    final set = _roleToPermissions.putIfAbsent(role, () => <String>{});
    if (!set.contains(permission)) {
      set.add(permission);
      await addAudit('rbac', 'Granted "$permission" to role "$role"');
      notifyListeners();
      await _persistRBAC();
    }
  }

  Future<void> revokePermissionFromRole(String role, String permission) async {
    final set = _roleToPermissions[role];
    if (set != null && set.remove(permission)) {
      await addAudit('rbac', 'Revoked "$permission" from role "$role"');
      notifyListeners();
      await _persistRBAC();
    }
  }

  bool roleHas(String role, String permission) {
    final set = _roleToPermissions[role];
    if (set == null) return false;
    return set.contains(permission);
  }

  // Search tuning (demo)
  final Map<String, String> _synonyms = { 'wire':'cable' };
  final Set<String> _bannedTerms = { 'spam', 'fraud' };
  final Map<String, double> _boosts = { 'copper': 1.2, 'pro': 1.1 };
  // Optional category-specific boosts: category => term => factor
  final Map<String, Map<String,double>> _categoryBoosts = {};
  Map<String,String> get synonyms => Map.unmodifiable(_synonyms);
  Set<String> get bannedTerms => Set.unmodifiable(_bannedTerms);
  Map<String,double> get boosts => Map.unmodifiable(_boosts);
  Map<String, Map<String,double>> get categoryBoosts => { for (final e in _categoryBoosts.entries) e.key: Map<String,double>.from(e.value) };
  Future<void> addSynonym(String a, String b) async { _synonyms[a] = b; await addAudit('search', 'Synonym $a → $b'); notifyListeners(); await _persistSearch(); }
  Future<void> removeSynonym(String a) async { _synonyms.remove(a); await addAudit('search', 'Removed synonym $a'); notifyListeners(); await _persistSearch(); }
  Future<void> addBanned(String term) async { _bannedTerms.add(term); await addAudit('search', 'Banned "$term"'); notifyListeners(); await _persistSearch(); }
  Future<void> removeBanned(String term) async { _bannedTerms.remove(term); await addAudit('search', 'Unbanned "$term"'); notifyListeners(); await _persistSearch(); }
  Future<void> setBoost(String term, double factor) async { _boosts[term] = factor; await addAudit('search', 'Boost $term=$factor'); notifyListeners(); await _persistSearch(); }
  Future<void> setCategoryBoost(String category, String term, double factor) async {
    final map = _categoryBoosts.putIfAbsent(category, () => {});
    map[term] = factor;
    await addAudit('search', 'Boost [$category] $term=$factor');
    notifyListeners();
    await _persistSearch();
  }

  // Geo management (demo)
  final Map<String, Map<String, List<String>>> _geo = {
    'Maharashtra': {
      'Mumbai': ['Andheri','Bandra','Dadar'],
      'Pune': ['Kothrud','Hinjewadi']
    },
    'Karnataka': {
      'Bengaluru': ['Whitefield','HSR','Indiranagar']
    },
  };
  double _defaultServiceRadiusKm = 25;
  // Optional per-city radius overrides: key format "State|City"
  final Map<String, double> _cityRadiusOverridesKm = {};
  Map<String, Map<String, List<String>>> get geo => _geo;
  double get defaultServiceRadiusKm => _defaultServiceRadiusKm;
  Map<String,double> get cityRadiusOverridesKm => Map.unmodifiable(_cityRadiusOverridesKm);
  Future<void> addState(String state) async { _geo.putIfAbsent(state, () => {}); await addAudit('geo', 'Added state $state'); notifyListeners(); await _persistGeo(); }
  Future<void> addCity(String state, String city) async { _geo[state] ??= {}; _geo[state]!.putIfAbsent(city, () => []); await addAudit('geo', 'Added city $city in $state'); notifyListeners(); await _persistGeo(); }
  Future<void> addArea(String state, String city, String area) async { _geo[state] ??= {}; _geo[state]![city] ??= []; if (!_geo[state]![city]!.contains(area)) _geo[state]![city]!.add(area); await addAudit('geo', 'Added area $area in $city, $state'); notifyListeners(); await _persistGeo(); }
  Future<void> removeArea(String state, String city, String area) async { _geo[state]?[city]?.remove(area); await addAudit('geo', 'Removed area $area in $city, $state'); notifyListeners(); await _persistGeo(); }
  Future<void> setDefaultRadius(double km) async { _defaultServiceRadiusKm = km; await addAudit('geo', 'Default radius set to $km km'); notifyListeners(); await _persistGeo(); }
  Future<void> setCityRadius(String state, String city, double km) async {
    _cityRadiusOverridesKm['$state|$city'] = km;
    await addAudit('geo', 'Radius for $city, $state set to $km km');
    notifyListeners();
    await _persistGeo();
  }
  Future<void> clearCityRadius(String state, String city) async {
    _cityRadiusOverridesKm.remove('$state|$city');
    await addAudit('geo', 'Cleared radius override for $city, $state');
    notifyListeners();
    await _persistGeo();
  }

  // System Ops (demo)
  bool _maintenanceMode = false;
  bool get maintenanceMode => _maintenanceMode;
  Future<void> setMaintenance(bool value) async { _maintenanceMode = value; await addAudit('system', 'Maintenance ${value? 'enabled':'disabled'}'); notifyListeners(); await _persistSystem(); }
  final List<String> _templates = ['Order Email', 'Lead Assignment'];
  List<String> get templates => List.unmodifiable(_templates);
  Future<void> addTemplate(String name) async { _templates.add(name); await addAudit('system', 'Template added: $name'); notifyListeners(); await _persistSystem(); }
  Future<void> backupNow() async { await addAudit('system', 'Backup executed'); }

  // DX helpers (demo)
  Future<void> seedDemoData() async {
    await addAudit('dev', 'Seeded demo data');
  }
  Future<void> reindexSearch() async { await addAudit('dev', 'Triggered search reindex'); }

  List<AdminUser> get allUsers => List.unmodifiable(_allUsers);
  Map<String, bool> get featureFlags => Map.unmodifiable(_featureFlags);
  List<AuditLog> get auditLogs => List.unmodifiable(_auditLogs.reversed);
  int get auditRetentionDays => _auditRetentionDays;
  set auditRetentionDays(int days) { _auditRetentionDays = days; notifyListeners(); _persistLogs(); }

  String exportAuditCsv() {
    final header = 'timestamp,area,message';
    final rows = _auditLogs.map((a)=>[
      a.timestamp.toIso8601String(),
      a.area,
      a.message.replaceAll(',', ' '),
    ].join(',')).join('\n');
    return '$header\n$rows';
  }

  // CRUD: Users (demo)
  Future<void> addUser(AdminUser user) async {
    _allUsers.add(user);
    await addAudit('users', 'Added user ${user.id} (${user.email})');
    notifyListeners();
  }

  Future<void> updateUser(AdminUser updated) async {
    final idx = _allUsers.indexWhere((u) => u.id == updated.id);
    if (idx != -1) {
      _allUsers[idx] = updated;
      await addAudit('users', 'Updated user ${updated.id}');
      notifyListeners();
    }
  }

  Future<void> deleteUser(String id) async {
    _allUsers.removeWhere((u) => u.id == id);
    await addAudit('users', 'Deleted user $id');
    notifyListeners();
  }

  Future<void> resetPassword(String id) async {
    await addAudit('users', 'Password reset initiated for $id');
    notifyListeners();
  }

  // Role/plan helpers
  Future<void> promoteToSeller(String id, {String plan = 'free'}) async {
    final idx = _allUsers.indexWhere((u) => u.id == id);
    if (idx == -1) return;
    final u = _allUsers[idx];
    final updated = u.copyWith(
      role: 'seller',
      isSeller: true,
      plan: plan,
      sellerProfile: u.sellerProfile ?? const SellerProfile(),
    );
    _allUsers[idx] = updated;
    await addAudit('users', 'Promoted $id to seller (plan=$plan)');
    notifyListeners();
  }

  Future<void> demoteToBuyer(String id) async {
    final idx = _allUsers.indexWhere((u) => u.id == id);
    if (idx == -1) return;
    final u = _allUsers[idx];
    final updated = u.copyWith(
      role: 'buyer',
      isSeller: false,
      plan: 'free',
      sellerProfile: null,
      status: u.status,
    );
    _allUsers[idx] = updated;
    await addAudit('users', 'Demoted $id to buyer');
    notifyListeners();
  }

  Future<AdminUser> createSeller({
    required String id,
    required String name,
    required String email,
    String plan = 'pro',
    SellerProfile? profile,
  }) async {
    final user = AdminUser(
      id: id,
      name: name,
      email: email,
      role: 'seller',
      status: 'active',
      createdAt: DateTime.now(),
      isSeller: true,
      plan: plan,
      sellerProfile: profile ?? const SellerProfile(),
    );
    _allUsers.add(user);
    await addAudit('users', 'Created seller $id (plan=$plan)');
    notifyListeners();
    return user;
  }

  Future<void> grantPlan(String id, String plan) async {
    final idx = _allUsers.indexWhere((u) => u.id == id);
    if (idx == -1) return;
    _allUsers[idx] = _allUsers[idx].copyWith(plan: plan);
    await addAudit('billing', 'Granted plan $plan to $id');
    notifyListeners();
  }

  Future<void> refund(String id, {required double amount, String? reason}) async {
    await addAudit('billing', 'Refunded $id amount=₹${amount.toStringAsFixed(2)} reason="${reason?.replaceAll('\n',' ') ?? ''}"');
    notifyListeners();
  }

  Future<void> toggleFlag(String key, bool value) async {
    _featureFlags[key] = value;
    addAudit('feature_flag', 'Toggled $key to $value');
    notifyListeners();
    await _persistFlags();
  }

  Future<void> addAudit(String area, String message) async {
    _auditLogs.add(AuditLog(
      timestamp: DateTime.now(),
      area: area,
      message: message,
    ));
    _pruneOldAudits();
    notifyListeners();
    await _persistLogs();
  }

  void _pruneOldAudits() {
    final cutoff = DateTime.now().subtract(Duration(days: _auditRetentionDays));
    _auditLogs.removeWhere((a) => a.timestamp.isBefore(cutoff));
  }

  Future<void> bulkUpdateUsersStatus(Iterable<String> userIds, String status) async {
    for (final id in userIds) {
      final idx = _allUsers.indexWhere((u) => u.id == id);
      if (idx != -1) {
        _allUsers[idx] = _allUsers[idx].copyWith(status: status);
      }
    }
    await addAudit('users', 'Bulk updated ${userIds.length} users to $status');
    notifyListeners();
  }

  void exportUsersCsv(void Function(String csv) onReady) {
    final header = 'id,name,email,role,status,createdAt,plan,isSeller';
    final rows = _allUsers
        .map((u) => [
              u.id,
              u.name,
              u.email,
              u.role,
              u.status,
              u.createdAt.toIso8601String(),
              u.plan,
              u.isSeller.toString(),
            ].join(','))
        .join('\n');
    final csv = '$header\n$rows';
    onReady(csv);
    addAudit('users', 'Exported users CSV (${_allUsers.length})');
  }

  Future<void> _hydrate() async {
    final prefs = await SharedPreferences.getInstance();
    // Flags
    final keys = _featureFlags.keys.toList();
    for (final k in keys) {
      final v = prefs.getBool('flag_$k');
      if (v != null) {
        _featureFlags[k] = v;
      }
    }
    // Logs
    final raw = prefs.getStringList('audit_logs') ?? [];
    _auditLogs
      ..clear()
      ..addAll(raw.map((s) {
        final parts = s.split('|');
        if (parts.length < 3) return AuditLog(timestamp: DateTime.now(), area: 'unknown', message: s);
        return AuditLog(timestamp: DateTime.parse(parts[0]), area: parts[1], message: parts.sublist(2).join('|'));
      }));
    _auditRetentionDays = prefs.getInt('audit_retention_days') ?? _auditRetentionDays;
    notifyListeners();

    // RBAC
    final rbacRaw = prefs.getStringList('rbac_roles') ?? [];
    if (rbacRaw.isNotEmpty) {
      _roleToPermissions
        ..clear()
        ..addAll({
          for (final line in rbacRaw)
            if (line.contains(':'))
              line.split(':')[0]: line.split(':').length > 1 && line.split(':')[1].isNotEmpty
                ? line.split(':')[1].split(',').where((e)=>e.isNotEmpty).toSet()
                : <String>{}
        });
    }

    // Search
    final syn = prefs.getStringList('search_synonyms') ?? [];
    if (syn.isNotEmpty) { _synonyms
      ..clear()
      ..addAll({ for (final s in syn) if (s.contains(':')) s.split(':')[0]: s.split(':')[1] }); }
    final ban = prefs.getStringList('search_banned') ?? [];
    if (ban.isNotEmpty) { _bannedTerms
      ..clear()
      ..addAll(ban); }
    final bst = prefs.getStringList('search_boosts') ?? [];
    if (bst.isNotEmpty) { _boosts
      ..clear()
      ..addAll({ for (final s in bst) if (s.contains(':')) s.split(':')[0]: double.tryParse(s.split(':')[1]) ?? 1.0 }); }
    final cbst = prefs.getStringList('search_category_boosts') ?? [];
    if (cbst.isNotEmpty) {
      _categoryBoosts
        ..clear();
      for (final s in cbst) {
        final parts = s.split('|');
        if (parts.length == 3) {
          final cat = parts[0];
          final term = parts[1];
          final factor = double.tryParse(parts[2]) ?? 1.0;
          _categoryBoosts.putIfAbsent(cat, () => {});
          _categoryBoosts[cat]![term] = factor;
        }
      }
    }

    // Geo
    _defaultServiceRadiusKm = prefs.getDouble('geo_radius') ?? _defaultServiceRadiusKm;
    final cityOverrides = prefs.getStringList('geo_city_radius') ?? [];
    _cityRadiusOverridesKm
      ..clear()
      ..addAll({
        for (final s in cityOverrides)
          if (s.contains(':')) s.split(':')[0]: double.tryParse(s.split(':')[1]) ?? _defaultServiceRadiusKm
      });

    // System
    _maintenanceMode = prefs.getBool('system_maintenance') ?? _maintenanceMode;
  }

  Future<void> _persistFlags() async {
    final prefs = await SharedPreferences.getInstance();
    for (final e in _featureFlags.entries) {
      await prefs.setBool('flag_${e.key}', e.value);
    }
  }

  Future<void> _persistLogs() async {
    final prefs = await SharedPreferences.getInstance();
    final list = _auditLogs
        .map((a) => '${a.timestamp.toIso8601String()}|${a.area}|${a.message.replaceAll('\n', ' ')}')
        .toList(growable: false);
    await prefs.setStringList('audit_logs', list);
    await prefs.setInt('audit_retention_days', _auditRetentionDays);
  }

  Future<void> _persistRBAC() async {
    final prefs = await SharedPreferences.getInstance();
    final list = _roleToPermissions.entries
        .map((e) => '${e.key}:${e.value.join(',')}')
        .toList(growable: false);
    await prefs.setStringList('rbac_roles', list);
  }

  Future<void> _persistSearch() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('search_synonyms', [ for (final e in _synonyms.entries) '${e.key}:${e.value}' ]);
    await prefs.setStringList('search_banned', _bannedTerms.toList());
    await prefs.setStringList('search_boosts', [ for (final e in _boosts.entries) '${e.key}:${e.value}' ]);
    final catList = <String>[];
    _categoryBoosts.forEach((cat, map) {
      map.forEach((term, factor) { catList.add('$cat|$term|$factor'); });
    });
    await prefs.setStringList('search_category_boosts', catList);
  }

  Future<void> _persistGeo() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('geo_radius', _defaultServiceRadiusKm);
    await prefs.setStringList('geo_city_radius', [ for (final e in _cityRadiusOverridesKm.entries) '${e.key}:${e.value}' ]);
  }

  Future<void> _persistSystem() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('system_maintenance', _maintenanceMode);
  }
}

class AdminUser {
  final String id;
  final String name;
  final String email;
  final String role; // admin | seller | buyer
  final String status; // active | pending | suspended
  final DateTime createdAt;
  final bool isSeller;
  final String plan; // free | plus | pro
  final SellerProfile? sellerProfile;

  const AdminUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    required this.status,
    required this.createdAt,
    this.isSeller = false,
    this.plan = 'free',
    this.sellerProfile,
  });

  AdminUser copyWith({
    String? name,
    String? email,
    String? role,
    String? status,
    bool? isSeller,
    String? plan,
    SellerProfile? sellerProfile,
  }) => AdminUser(
        id: id,
        name: name ?? this.name,
        email: email ?? this.email,
        role: role ?? this.role,
        status: status ?? this.status,
        createdAt: createdAt,
        isSeller: isSeller ?? this.isSeller,
        plan: plan ?? this.plan,
        sellerProfile: sellerProfile ?? this.sellerProfile,
      );
}

class SellerProfile {
  final String legalName;
  final String gstin;
  final String phone;
  final String address;
  final String bannerUrl;
  final List<String> materials;
  final Map<String, String> customFields;

  const SellerProfile({
    this.legalName = '',
    this.gstin = '',
    this.phone = '',
    this.address = '',
    this.bannerUrl = '',
    this.materials = const [],
    this.customFields = const {},
  });

  SellerProfile copyWith({
    String? legalName,
    String? gstin,
    String? phone,
    String? address,
    String? bannerUrl,
    List<String>? materials,
    Map<String,String>? customFields,
  }) => SellerProfile(
    legalName: legalName ?? this.legalName,
    gstin: gstin ?? this.gstin,
    phone: phone ?? this.phone,
    address: address ?? this.address,
    bannerUrl: bannerUrl ?? this.bannerUrl,
    materials: materials ?? this.materials,
    customFields: customFields ?? this.customFields,
  );
}

class AuditLog {
  final DateTime timestamp;
  final String area;
  final String message;

  const AuditLog({
    required this.timestamp,
    required this.area,
    required this.message,
  });
}


