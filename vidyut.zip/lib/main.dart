import 'package:flutter/widgets.dart';
import 'app/app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VidyutApp());
}
